#include <iostream>

class Distance
{
private:
	int feet = 0;
	float inches = 0;

public:
	void setDistance(int ft, float in);
	void getDistance();

	Distance operator+ (const Distance& dist)
	{
		Distance sumDistance;
		sumDistance.feet = this->feet + dist.feet;
		sumDistance.inches = this->inches + dist.inches;
		return sumDistance;
	}
};

void Distance::setDistance(int ft, float in)
{
	feet = ft;
	inches = in;
	while (inches > 12)
	{
		inches -= 12;
		feet += 1;
	}
}

void Distance::getDistance()
{
	std::cout << feet << "'- " << inches << '"';
}

int main()
{
	Distance dist;
	dist.setDistance(5, 13);
	dist.getDistance();
	return 0;
}